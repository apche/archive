grant create view to RPCHSK;
grant create procedure to RPCHSK;
grant create sequence to RPCHSK;
grant create table to RPCHSK;
grant create database link to RPCHSK;