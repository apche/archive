create table PAR_ARCH_TABLES(
  ID NUMBER NOT NULL
, TABLE_NAME VARCHAR2(30) NOT NULL
, ARCH_TABLE_NAME VARCHAR2(30) NOT NULL
, AMND_STATE VARCHAR2(1) NOT NULL
, AMND_DATE DATE NOT NULL
, TRANSFORMATION_TYPE VARCHAR2(30) NOT NULL
, PRIORITY NUMBER NOT NULL
, ARCH_TABLES_MASK VARCHAR2(4000) NOT NULL
);

alter table PAR_ARCH_TABLES add constraint PAR_ARCH_TABLES_PK primary key (ID);

comment on column PAR_ARCH_TABLES.ID IS 'Primary key';
comment on column PAR_ARCH_TABLES.TABLE_NAME IS 'Original table name in OWS schema';
comment on column PAR_ARCH_TABLES.ARCH_TABLE_NAME IS 'Table name in Archive database';
comment on column PAR_ARCH_TABLES.AMND_STATE IS 'Status of row A � Active I � Inactive';
comment on column PAR_ARCH_TABLES.AMND_DATE IS 'Valid from date';
comment on column PAR_ARCH_TABLES.TRANSFORMATION_TYPE IS 'Transformation trype : STANDARD, XXXXX...';
comment on column PAR_ARCH_TABLES.PRIORITY IS 'Priority destecending order';
comment on column PAR_ARCH_TABLES.ARCH_TABLES_MASK IS 'Regexp mask for archive tables';

grant select on PAR_ARCH_TABLES to rpc_data_read;