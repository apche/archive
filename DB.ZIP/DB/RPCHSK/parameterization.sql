
-------------------------------- Delete old data  just on pre-prod ------------------------------------

delete from PAR_ARCH_TABLES;

-------------------------------- Insert configuration ------------------------------------

insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'APPL_STANDING_ORDER','APPL_STANDING_ORDER', 'A', trunc(sysdate), 'STANDARD', 100, '^_[0-9]{4,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'APPL_TARIFF_DATA','APPL_TARIFF_DATA', 'A', trunc(sysdate), 'STANDARD', 100, '^_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'APPL_USAGE_TEMPL','APPL_USAGE_TEMPL', 'A', trunc(sysdate), 'STANDARD', 100, '^_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'ACQ_CST_CYCLE','ACQ_CST_CYCLE', 'A', trunc(sysdate), 'STANDARD', 100, '^ACQ_CST_CYCLE_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'ACQ_DEV_CYCLE','ACQ_DEV_CYCLE','A', trunc(sysdate), 'STANDARD', 100, '^ACQ_DEV_CYCLE_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'ADDENDUM_DOC','ADDENDUM_DOC','A', trunc(sysdate), 'STANDARD', 100, '^ADDENDUM_DOC_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'ADV_APPL','ADV_APPL','A', trunc(sysdate), 'STANDARD', 100, '^ADV_APPL_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'APPL_ACNT','APPL_ACNT','A', trunc(sysdate), 'STANDARD', 100, '^APPL_ACNT_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'APPL_ACTION','APPL_ACTION','A', trunc(sysdate), 'STANDARD', 100, '^APPL_ACTION_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'APPL_ADDRESS','APPL_ADDRESS','A', trunc(sysdate), 'STANDARD', 100, '^APPL_ADDRESS_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'APPL_CARD_INFO','APPL_CARD_INFO','A', trunc(sysdate), 'STANDARD', 100, '^APPL_CARD_INFO_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'APPL_CLIENT','APPL_CLIENT','A', trunc(sysdate), 'STANDARD', 100, '^APPL_CLIENT_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'APPL_CONTRACT','APPL_CONTRACT', 'A', trunc(sysdate), 'STANDARD', 100, '^APPL_CONTRACT_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'APPL_INFO','APPL_INFO','A', trunc(sysdate), 'STANDARD', 100, '^APPL_INFO_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'APPL_LOG','APPL_LOG','A', trunc(sysdate), 'STANDARD', 100, '^APPL_LOG_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'CM_CASE','CM_CASE','A', trunc(sysdate), 'STANDARD', 100, '^CM_CASE_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'CM_CASE_ACTIV','CM_CASE_ACTIV','A', trunc(sysdate), 'STANDARD', 100, '^CM_CASE_ACTIV_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'CM_CASE_AMOUNT','CM_CASE_AMOUNT','A', trunc(sysdate), 'STANDARD', 100, '^CM_CASE_AMOUNT_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'CM_CASE_EVENT','CM_CASE_EVENT','A', trunc(sysdate), 'STANDARD', 100, '^CM_CASE_EVENT_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'CM_CASE_MAP','CM_CASE_MAP','A', trunc(sysdate), 'STANDARD', 100, '^CM_CASE_MAP_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'CM_CASE_OBJ','CM_CASE_OBJ','A', trunc(sysdate), 'STANDARD', 100, '^CM_CASE_OBJ_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'CM_CASE_PARM','CM_CASE_PARM','A', trunc(sysdate), 'STANDARD', 100, '^CM_CASE_PARM_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'CM_CASE_RULE','CM_CASE_RULE','A', trunc(sysdate), 'STANDARD', 100, '^CM_CASE_RULE_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'CM_PEND_EVNT','CM_PEND_EVNT','A', trunc(sysdate), 'STANDARD', 100, '^CM_PEND_EVNT_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'COMS_LOG','COMS_LOG','A', trunc(sysdate), 'STANDARD', 100, '^COMS_LOG_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'CREDIT_HISTORY','CREDIT_HISTORY','A', trunc(sysdate), 'STANDARD', 100, '^CREDIT_HISTORY_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'DEVICE_STAT','DEVICE_STAT','A', trunc(sysdate), 'STANDARD', 100, '^DEVICE_STAT_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'DEVICE_STAT_DOC','DEVICE_STAT_DOC','A', trunc(sysdate), 'STANDARD', 100, '^DEVICE_STAT_DOC_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'DOC','DOC','A', trunc(sysdate), 'STANDARD', 100, '^DOC_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'ENTRY','ENTRY','A', trunc(sysdate), 'STANDARD', 100, '^ENTRY_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'FILE_INFO','FILE_INFO','A', trunc(sysdate), 'STANDARD', 100, '^FILE_INFO_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'FILE_RECORD','FILE_RECORD','A', trunc(sysdate), 'STANDARD', 100, '^FILE_RECORD_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'GL_TRACE','GL_TRACE','A', trunc(sysdate), 'STANDARD', 100, '^GL_TRACE_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'INVOICE_PARTY','INVOICE_PARTY','A', trunc(sysdate), 'STANDARD', 100, '^INVOICE_PARTY_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'ITEM','ITEM','A', trunc(sysdate), 'STANDARD', 100, '^ITEM_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'ITEM_DUE','ITEM_DUE','A', trunc(sysdate), 'STANDARD', 100, '^ITEM_DUE_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'M_TRANSACTION','M_TRANSACTION','A', trunc(sysdate), 'STANDARD', 100, '^M_TRANSACTION_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'ORIGINAL_DOC','ORIGINAL_DOC','A', trunc(sysdate), 'STANDARD', 100, '^ORIGINAL_DOC_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'PROCESS_MESS','PROCESS_MESS','A', trunc(sysdate), 'STANDARD', 100, '^PROCESS_MESS_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'TD_DOC','TD_DOC','A', trunc(sysdate), 'STANDARD', 100, '^TD_DOC_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'TRANS_DISPENSE','TRANS_DISPENSE','A', trunc(sysdate), 'STANDARD', 100, '^TRANS_DISPENSE_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'TREE_HEADER','TREE_HEADER','A', trunc(sysdate), 'STANDARD', 100, '^TREE_HEADER_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'TREE_NODE','TREE_NODE','A', trunc(sysdate), 'STANDARD', 100, '^TREE_NODE_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'USAGE_HISTORY','USAGE_HISTORY','A', trunc(sysdate), 'STANDARD', 100, '^USAGE_HISTORY_[0-9]{6,}' from dual;
insert into PAR_ARCH_TABLES select SEQ_PAR_ARCH_TABLES.nextval, 'USAGE_LIMITER','USAGE_LIMITER','A', trunc(sysdate), 'STANDARD', 100, '^USAGE_LIMITER_[0-9]{6,}' from dual;


commit;


-------------------------------- Recreate views ------------------------------------

begin
	TBX_ARCH_UTILS.p_recreate_local_views;
end;
/
