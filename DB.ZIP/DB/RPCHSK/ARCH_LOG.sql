create table ARCH_LOG(
  ID NUMBER NOT NULL
 , LOG_DATETIME DATE NOT NULL 
 , log_type varchar2(1) not null
 , log_proc varchar2(200) not null
 , log_msg varchar2(4000)
);

grant select on ARCH_LOG to rpc_data_read;