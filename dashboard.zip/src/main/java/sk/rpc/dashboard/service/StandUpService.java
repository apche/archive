package sk.rpc.dashboard.service;



import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;


import sk.rpc.dashboard.domain.StandUpDomain;
import sk.rpc.dashboard.repository.StandUpRepository;

@Component
@RequestScope
public class StandUpService {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	 
	@Autowired
	private StandUpRepository standUpRepository;
	
	private List<String> rows;
	private List<String> columns;
	private ArrayList<ArrayList<ArrayList<StandUpDomain>>> data;
	private String weekCurrent;
	private Date dateCurrent;
	private String weekNext;
	private String weekPrev;
		
	public StandUpService() {
		super();
		rows = new ArrayList<String>();
		columns = new ArrayList<String>();
		data = new ArrayList<ArrayList<ArrayList<StandUpDomain>>>();
		
	}

	public String getDateFromWeek( String week){
		
		Calendar cal = Calendar.getInstance();
		String out = "";
		
		

		String[] array = week.split("_", -1);

		if(array.length == 3){
			cal.setWeekDate(Integer.parseInt(array[0]), Integer.parseInt(array[1]), Integer.parseInt(array[2]));
			out = String.format( "%02d", cal.get(Calendar.DAY_OF_MONTH)) + "." + 
					String.format( "%02d", cal.get(Calendar.MONTH)) + "." + 
					Integer.toString( cal.get(Calendar.YEAR));
		}
		else
			out = array[0] + "\\w" + array[1];
		return out;
		
	}
	private String getWeekCode( Calendar cal){
		return Integer.toString( cal.get(Calendar.YEAR)) + "_" + String.format( "%02d", cal.get(Calendar.WEEK_OF_YEAR));

	}
	public void loadData(String teamName, String week, String userName ){
		
		Calendar cal = Calendar.getInstance();
		
		rows.clear();
		columns.clear();
		data.clear();
		
		if( week.equalsIgnoreCase("current")){
			cal.setTime( new Date());
		}else if( week.equalsIgnoreCase("prev")){
			cal.setTime( new Date());
			cal.add(Calendar.DAY_OF_YEAR, -7);
		}else{
			String[] array = week.split("_", -1);
			cal.setWeekDate(Integer.parseInt(array[0]), Integer.parseInt(array[1]), 6);
		}
		weekCurrent = getWeekCode( cal);
		dateCurrent = cal.getTime();
		cal.add(Calendar.DAY_OF_YEAR, -7);
		weekPrev = getWeekCode( cal);
		cal.add(Calendar.DAY_OF_YEAR, +14);
		weekNext = getWeekCode( cal);
			
		jdbcTemplate.query( getSql( teamName, weekCurrent,userName), 
				(rs, rowNum) -> new StandUpDomain( rs.getLong("id"), rs.getTimestamp("last_updated_datetime"), rs.getString("period_code"), 
						rs.getString("username"),rs.getLong("order_by"),
						rs.getLong("color"),rs.getString("issue"),
						rs.getDouble("effort_estimation"),rs.getDouble("effort_real"),
						rs.getString("description"),rs.getString("period_type"),
						rs.getDouble("week_effort_estimation"),rs.getDouble("week_effort_real"),
						rs.getString("issue_info")
						)
		).forEach( standUp ->  addStandUpModel(standUp)
		);		
	
	}
	
	public void processRequest( Map<String,String> allRequestParams){
		
		
		for(int r = 0; r < rows.size(); r++ ){
			for( int c = 0; c < columns.size();c++){
				ArrayList<StandUpDomain> d = data.get(r).get(c);
				for(int o = 0; o < d.size();o++){
					processRequest(allRequestParams, r, c, data.get(r).get(c).get(o) );
				}
			}
		}
	}
	private void processRequest(Map<String,String> allRequestParams,int rowIndex, int colIndex, StandUpDomain standUpModel ){
		String id = allRequestParams.get(getElementName("id", rowIndex, colIndex, standUpModel));
		String lastUpdatedDateTime = allRequestParams.get(getElementName("lastUpdatedDateTime", rowIndex, colIndex, standUpModel));
		String periodCode = allRequestParams.get(getElementName("periodCode", rowIndex, colIndex, standUpModel));
		String userName = allRequestParams.get(getElementName("userName", rowIndex, colIndex, standUpModel));
		String orderBy = allRequestParams.get(getElementName("orderBy", rowIndex, colIndex, standUpModel));
		String description = allRequestParams.get(getElementName("description", rowIndex, colIndex, standUpModel));
		String color = allRequestParams.get(getElementName("color", rowIndex, colIndex, standUpModel));
		String effortReal = allRequestParams.get(getElementName("effortReal", rowIndex, colIndex, standUpModel));
		String effortEstimation = allRequestParams.get(getElementName("effortEstimation", rowIndex, colIndex, standUpModel));
		String issue = allRequestParams.get(getElementName("issue", rowIndex, colIndex, standUpModel));
		
		/* Check if the data are correct for row, column, order and id*/
		if (! orderBy.equals(standUpModel.getOrderBy().toString()) ||
				! userName.equals(standUpModel.getUserName()) ||
				! periodCode.equals(standUpModel.getPeriodCode())  ||
				! id.equals(standUpModel.getId().toString())){
			System.out.println(  ";id :" + id + "!=" + standUpModel.getId().toString() +
					";Order by :" + orderBy + "!=" + standUpModel.getOrderBy().toString() +
					";userName :" + userName + "!=" + standUpModel.getUserName() +
					";periodCode :" + periodCode + "!=" + standUpModel.getPeriodCode()
			);
		}
		else{
			if (id.equals("0")){ // New record
				if (! issue.equals("")){ // Save only when issues is set
					setStandUpModel(standUpModel, issue, color, description, effortReal, effortEstimation );
					standUpModel.setLastUpdatedDateTime(new Date() );
					StandUpDomain standUpModelSaved = standUpRepository.save( standUpModel);
					standUpModel.setId( standUpModelSaved.getId() );
					standUpModel.setMsg("Created");
				}
			}else{ // update or delete record
				if ( issue.equals("")){ // Delete
					
					standUpRepository.delete( standUpModel);
					
					setStandUpModel(standUpModel, issue, color, description, effortReal, effortEstimation );
					standUpModel.setLastUpdatedDateTime( null);
					standUpModel.setId(new Long(0));
					setStandUpModel( standUpModel, "", "1", "", "0", "0");
					standUpModel.setMsg("Deleted");
				}else{
					if ( 	! issue.equals(standUpModel.getIssue()) ||
							! color.equals(standUpModel.getColor().toString()) ||
							! description.equals(standUpModel.getDescription()) ||
							! effortReal.equals(standUpModel.getEffortReal().toString()) ||
							! effortEstimation.equals(standUpModel.getEffortEstimation().toString()) 
							){ // update only if there is a change
						
						System.out.println("Update try:" +
							"issue:'" + issue + "':'" + standUpModel.getIssue() + "'" +
							"color:'" + color + "':'" + standUpModel.getColor().toString() + "'" + 
							"description:'" + description + "':'" + standUpModel.getDescription() + "'" + 
							"effortReal:'" + effortReal + "':'" + standUpModel.getEffortReal().toString() + "'" + 
							"effortEstimation:'" + effortEstimation + "':'" + standUpModel.getEffortEstimation().toString() + "'" + 
							"lastUpdatedDateTime:'" + lastUpdatedDateTime + "':'" + standUpModel.getLastUpdatedDateTime().toString() + "'"
						);

						
						setStandUpModel(standUpModel, issue, color, description, effortReal, effortEstimation );
						standUpModel.setLastUpdatedDateTime(new Date() );
						standUpRepository.save( standUpModel);
						standUpModel.setMsg("Updated");
					}
				}
			}
				
		}
		
		
	}
	private void setStandUpModel( StandUpDomain standUpModel,String issue, String color,String description, String effortReal, String effortEstimation ){
		standUpModel.setIssue(issue);
		standUpModel.setColor(Long.valueOf(color) );
		standUpModel.setDescription(description);
		standUpModel.setEffortEstimation(Double.valueOf(effortEstimation.replace(",",".")));
		standUpModel.setEffortReal(Double.valueOf(effortReal.replace(",",".")));

	}
	public void addStandUpModel(StandUpDomain standUpModel ){
		int index_row;
		int index_column;
		index_row = addRowIfNotExists( standUpModel.getPeriodType());
		index_column = addColumnIfNotExists( standUpModel.getUserName() );
		try {
			data.get( index_row).get(index_column).add( standUpModel);
		}
		catch ( Exception e){
			System.out.println( e.toString());
		}
	}
	public int addColumnIfNotExists( String colCode){
		int index_column;
		index_column = columns.indexOf( colCode );
		if ( index_column == -1)
		{
			columns.add( colCode);
			index_column = columns.indexOf( colCode );
			/* Add new column into all existing rows */
			data.forEach( row -> row.add( new ArrayList<StandUpDomain>() )
					);
			
		}
		return index_column;
	}
	public int addRowIfNotExists( String rowCode){
		int index_row;
		index_row = rows.indexOf( rowCode );
		if ( index_row == -1 )
		{
			rows.add( rowCode);
			index_row = rows.indexOf( rowCode );
			data.add( new ArrayList<ArrayList<StandUpDomain>>());
			/* add all existing Columns into new row */
			for ( String colCode : columns){
				data.get( index_row).add( new ArrayList<StandUpDomain>() );
			}
			
		}
		return index_row;
	}
	public String getSql( String teamName, String week, String userName){
		String sql = "select tm.*, po.*, s.color, s.issue, " +
				"	s.effort_estimation, s.effort_real, s.description  , s.id, s.last_updated_datetime, " +
				"	total_week.week_effort_real, total_week.week_effort_estimation, " +
				"   jb.summary issue_info" +
				"	from MV_JIRA_USERS tm " +
				"	join (  " +
				"		select '" + week + "' period_code, 'Issues' period_type, o.id order_by  " +
				"			from dual p " +
				"			join (select level id from dual connect by level <=8) o on (1=1) " +
				"		" +
				"		union all " +
				"		select concat( '" + week + "_', p.id) period_code, " +
				"			case p.id when 1 then 'Mon' when 2 then 'Tue' when 3 then 'Wed' when 4 then 'Thr' when 5 then 'Fri'  " +
				"			end period_type, " +
				"			o.id order_by  " +
				"			from (select level id from dual connect by level <=5) p " +
				"			join (select level id from dual connect by level <=6) o on (1=1) " +
				"		" +
				"	) po on (1=1)" +
				"	left join stand_up s on ( s.username = tm.username and s.period_code = po.period_code and s.order_by = po.order_by)  " +
				"	left join (" +
				"	select " +
				"		substr( period_code, 1, 7) period_code, username, issue, " +
				"		sum( effort_real) week_effort_real," +
				"		sum( effort_estimation) week_effort_estimation" +
				"		from stand_up s where length( period_code) > 8" +
				"		group by substr( period_code, 1, 7), username, issue" +
				"	) total_week on ( s.username = total_week.username" +
				"	and s.period_code         = total_week.period_code" +
				"	and s.issue = total_week.issue" +
				"	)" +
				"	left join JIRA_BASE jb on ( jb.issue = s.issue) " +
				"	where tm.show_in_stand_up = 1 and tm.teamname = '" + teamName + "' ";
		if (! userName.equals(""))
			sql += "	and tm.username = '" + userName + "'";	
		sql += "	order by po.period_code, tm.username, po.order_by ";
		System.out.println(sql);
		return sql;
	}
	public ArrayList<StandUpDomain> getData(int rowIndex, int colIndex){
		return data.get(rowIndex).get(colIndex);
	}
	public String getElementName( String elemantPrefix,int rowIndex, int colIndex, int orderByIndex){
		return getElementName(elemantPrefix,  rowIndex, colIndex, data.get(rowIndex).get(colIndex).get(orderByIndex));
		/*return elemantPrefix + '_' + rowIndex + '_' +  colIndex + '_' + 
				data.get(rowIndex).get(colIndex).get(orderByIndex).getOrderBy().toString();
				*/
	}	
	public String getElementName( String elemantPrefix,int rowIndex, int colIndex, StandUpDomain standUpModel)
	{
		return elemantPrefix + '_' + rowIndex + '_' +  colIndex + '_' + standUpModel.getOrderBy().toString();
	}
	public List<String> getRows() {
		return rows;
	}

	public void setRows(List<String> rows) {
		this.rows = rows;
	}

	public List<String> getColumns() {
		return columns;
	}

	public void setColumns(List<String> columns) {
		this.columns = columns;
	}

	public ArrayList<ArrayList<ArrayList<StandUpDomain>>> getData() {
		return data;
	}

	public void setData(ArrayList<ArrayList<ArrayList<StandUpDomain>>> data) {
		this.data = data;
	}




	public String getWeekCurrent() {
		return weekCurrent;
	}


	public void setWeekCurrent(String weekCurrent) {
		this.weekCurrent = weekCurrent;
	}


	public String getWeekNext() {
		return weekNext;
	}


	public void setWeekNext(String weekNext) {
		this.weekNext = weekNext;
	}


	public String getWeekPrev() {
		return weekPrev;
	}


	public void setWeekPrev(String weekPrev) {
		this.weekPrev = weekPrev;
	}

	public Date getDateCurrent() {
		return dateCurrent;
	}

	public void setDateCurrent(Date dateCurrent) {
		this.dateCurrent = dateCurrent;
	}

}
