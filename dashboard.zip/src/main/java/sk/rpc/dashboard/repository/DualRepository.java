package sk.rpc.dashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import sk.rpc.dashboard.domain.TestDomain;

public interface DualRepository extends Repository<TestDomain, Long> {
	
	@Query(value = "select 1 AS id,'test' AS name from dual", nativeQuery = true)
	public List<TestDomain> getAll();
	
	@Query(value = "select 1 AS id,'test' AS name from dual where 1=1 and '1' in (?1)", nativeQuery = true)
	public List<TestDomain> getByName(String andCondition);
	

}
