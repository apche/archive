package sk.rpc.dashboard.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

import sk.rpc.dashboard.domain.DashboardPagesDomain;

public interface DashboardPagesRepository extends JpaRepository<DashboardPagesDomain, Long>{
	
	List<DashboardPagesDomain> findByDashboardName(String dashboardname);
	
	List<DashboardPagesDomain> findAll();

}
