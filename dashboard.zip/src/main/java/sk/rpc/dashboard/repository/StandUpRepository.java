package sk.rpc.dashboard.repository;

import org.springframework.data.repository.CrudRepository;

import sk.rpc.dashboard.domain.StandUpDomain;

public interface StandUpRepository extends CrudRepository<StandUpDomain, Long>{

}
