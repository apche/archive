package sk.rpc.dashboard.repository;

import org.springframework.data.repository.CrudRepository;

import sk.rpc.dashboard.domain.ProjectDomain;

public interface ProjectRepository extends CrudRepository<ProjectDomain, Long>{

}
