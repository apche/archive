package sk.rpc.dashboard.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="dashboard_pages")

@NamedNativeQuery(name = "DashboardPages.findByDashboardName",
query = "select * from dashboard_pages p where p.dashboard_name = ?1  order by page_order", resultClass = DashboardPagesDomain.class)
public class DashboardPagesDomain {



	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	@Column(name="dashboard_name")
	private String dashboardName;
	@Column(name="page_name")
	private String pageName;
	@Column(name="page_url")
	private String pageURL;
	@Column(name="page_order")
	private Long pageOrder;

	public DashboardPagesDomain(){
		
	}
    public DashboardPagesDomain(Long id, String dashboardName, String pageName, String pageURL, Long pageOrder) {
		super();
		this.id = id;
		this.dashboardName = dashboardName;
		this.pageName = pageName;
		this.pageURL = pageURL;
		this.pageOrder = pageOrder;
	}	
	
	public String getDashboardName() {
		return dashboardName;
	}
	public void setDashboardName(String dashboardName) {
		this.dashboardName = dashboardName;
	}
	public String getPageName() {
		return pageName;
	}
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	public String getPageURL() {
		return pageURL;
	}
	public void setPageURL(String pageURL) {
		this.pageURL = pageURL;
	}
	public Long getPageOrder() {
		return pageOrder;
	}
	public void setPageOrder(Long pageOrder) {
		this.pageOrder = pageOrder;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "DashboardPages [id=" + id + ", dashboardName=" + dashboardName + ", pageName=" + pageName + ", pageURL="
				+ pageURL + ", pageOrder=" + pageOrder + "]";
	}
	
}
