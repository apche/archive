package sk.rpc.dashboard.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="dashboard_project")
@SequenceGenerator(name="seq_dashboard_project", sequenceName="seq_dashboard_project")
public class ProjectDomain {

	@Column( name="id", updatable = false)
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="seq_dashboard_project")
	private Long id;
	
	@Column( name="last_updated_datetime")
	private Date lastUpdatedDateTime;
	
	@Column( name="username")
	private String userName;

	@Column( name="teamname")
	private String teamName;
	
	@Column( name="proj_status")
	private String projectStatus;
	
	@Column( name="proj_name")
	private String projectName;	

	@Column( name="proj_manager")
	private String projectManager;

	@Transient
	private String lastPeriod;

	@Transient
	private String userNameDesc;

	public ProjectDomain(Long id, Date lastUpdatedDateTime, String userName, String teamName, String projectStatus,
			String projectName, String projectManager, String lastPeriod, String userNameDesc) {
		super();
		this.id = id;
		this.lastUpdatedDateTime = lastUpdatedDateTime;
		this.userName = userName;
		this.teamName = teamName;
		this.projectStatus = projectStatus;
		this.projectName = projectName;
		this.projectManager = projectManager;
		this.lastPeriod = lastPeriod;
		this.userNameDesc = userNameDesc;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}

	public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getProjectStatus() {
		return projectStatus;
	}

	public void setProjectStatus(String projectStatus) {
		this.projectStatus = projectStatus;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectManager() {
		return projectManager;
	}

	public void setProjectManager(String projectManager) {
		this.projectManager = projectManager;
	}

	public String getLastPeriod() {
		return lastPeriod;
	}

	public void setLastPeriod(String lastPeriod) {
		this.lastPeriod = lastPeriod;
	}

	public String getUserNameDesc() {
		return userNameDesc;
	}

	public void setUserNameDesc(String userNameDesc) {
		this.userNameDesc = userNameDesc;
	}	
	
}
