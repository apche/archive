package sk.rpc.dashboard.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Table;


@Embeddable

@Table(name="jira_base")
public class JiraBaseDomain {

	@Column(name="id")
	private Long id;
	@Column(name="issue")
	private String issue;
	@Column(name="summary")
	private String summary;
	@Column(name="issue_type")
	private String issueType;
	@Column(name="issue_status")
	private String issueStatus;
	@Column(name="issue_resolution")
	private String issueResolution;
	@Column(name="assignee")
	private String assignee;
	@Column(name="reporter")
	private String reporter;
	@Column(name="created")
	private Date created;
	@Column(name="updated")
	private Date updated;

	public JiraBaseDomain() {
		super();
	}
	
	public JiraBaseDomain(Long id, String issue, String summary, String issueType, String issueStatus,
			String issueResolution, String assignee, String reporter, Date created, Date updated) {
		super();
		this.id = id;
		this.issue = issue;
		this.summary = summary;
		this.issueType = issueType;
		this.issueStatus = issueStatus;
		this.issueResolution = issueResolution;
		this.assignee = assignee;
		this.reporter = reporter;
		this.created = created;
		this.updated = updated;
	}
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getIssue() {
		return issue;
	}
	public void setIssue(String issue) {
		this.issue = issue;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getIssueType() {
		return issueType;
	}
	public void setIssueType(String issueType) {
		this.issueType = issueType;
	}
	public String getIssueStatus() {
		return issueStatus;
	}
	public void setIssueStatus(String issueStatus) {
		this.issueStatus = issueStatus;
	}
	public String getIssueResolution() {
		return issueResolution;
	}
	public void setIssueResolution(String issueResolution) {
		this.issueResolution = issueResolution;
	}
	public String getAssignee() {
		return assignee;
	}
	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}
	public String getReporter() {
		return reporter;
	}
	public void setReporter(String reporter) {
		this.reporter = reporter;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public Date getUpdated() {
		return updated;
	}
	public void setUpdated(Date updated) {
		this.updated = updated;
	}

}
