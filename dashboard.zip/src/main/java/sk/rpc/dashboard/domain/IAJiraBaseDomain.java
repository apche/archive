package sk.rpc.dashboard.domain;

import java.util.Date;

public class IAJiraBaseDomain {

	private IADomain iaDomain;
	private JiraBaseDomain jiraBaseDomain; 
	
	
	
	
	public IAJiraBaseDomain(IADomain iaDomain, JiraBaseDomain jiraBaseDomain) {
		super();
		this.iaDomain = iaDomain;
		this.jiraBaseDomain = jiraBaseDomain;
	}

	public IADomain getIaDomain() {
		return iaDomain;
	}

	public void setIaDomain(IADomain iaDomain) {
		this.iaDomain = iaDomain;
	}

	public JiraBaseDomain getJiraBaseDomain() {
		return jiraBaseDomain;
	}

	public void setJiraBaseDomain(JiraBaseDomain jiraBaseDomain) {
		this.jiraBaseDomain = jiraBaseDomain;
	}
	
	public String getStatusClass(){
		if (iaDomain.getStatus().equals("A") ){
			if ( iaDomain.getPromisedDate().after( new Date() ) )
				return "good";
			else
				return "bad";
	
		}
		else{
			if ( iaDomain.getPromisedDate().before( iaDomain.getFinishedDate()) )
				return "finishedlate";				
			else
				return "finished";

		}
	}
	
}
