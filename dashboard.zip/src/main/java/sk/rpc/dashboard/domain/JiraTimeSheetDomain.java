package sk.rpc.dashboard.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.NamedNativeQuery;

@Embeddable

@NamedNativeQuery(name = "JiraTimeSheet.findByWeekAndTeamName",
query = "select * from table( pck_jira.f_getTimeSheet( ?, ?))", resultClass = JiraTimeSheetDomain.class)

public class JiraTimeSheetDomain {


	@Column(name="week")
	private String week;

	@Column(name="teamname")
	private String teamName;
	@Column(name="display_name")
	private String userName;
	@Column(name="jira_hours")
	private Double hoursJira;
	@Column(name="hours_to_compare")
	private Double hoursToCompare;
	@Column(name="hours_in_week")
	private Double hoursInWeek;
	@Column(name="perc")
	private Double hoursPerc;
	@Column(name="na_pivo_centy")
	private Long centyNaPivo;
	@Column(name="author")
	private String userShortName;
	@Column(name="author_issues")
	private String issuesDetails;

	public JiraTimeSheetDomain(){
		
	}
	
	public JiraTimeSheetDomain(String week, String teamName, String userName, Double hoursJira, Double hoursToCompare,
			Double hoursInWeek, Double hoursPerc, Long centyNaPivo, String userShortName, String issuesDetails) {
		super();
		this.week = week;
		this.teamName = teamName;
		this.userName = userName;
		this.hoursJira = hoursJira;
		this.hoursToCompare = hoursToCompare;
		this.hoursInWeek = hoursInWeek;
		this.hoursPerc = hoursPerc;
		this.centyNaPivo = centyNaPivo;
		this.userShortName = userShortName;
		this.issuesDetails = issuesDetails;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Double getHoursJira() {
		return hoursJira;
	}
	public void setHoursJira(Double hoursJira) {
		this.hoursJira = hoursJira;
	}
	public Double getHoursToCompare() {
		return hoursToCompare;
	}
	public void setHoursToCompare(Double hoursToCompare) {
		this.hoursToCompare = hoursToCompare;
	}
	public Double getHoursInWeek() {
		return hoursInWeek;
	}
	public void setHoursInWeek(Double hoursInWeek) {
		this.hoursInWeek = hoursInWeek;
	}
	public Double getHoursPerc() {
		return hoursPerc;
	}
	public void setHoursPerc(Double hoursPerc) {
		this.hoursPerc = hoursPerc;
	}
	public Long getCentyNaPivo() {
		return centyNaPivo;
	}
	public void setCentyNaPivo(Long centyNaPivo) {
		this.centyNaPivo = centyNaPivo;
	}
	public String getUserShortName() {
		return userShortName;
	}
	public void setUserShortName(String userShortName) {
		this.userShortName = userShortName;
	}
	public String getIssuesDetails() {
		return issuesDetails;
	}
	public void setIssuesDetails(String issuesDetails) {
		this.issuesDetails = issuesDetails;
	}
	public String getWeek() {
		return week;
	}

	public void setWeek(String week) {
		this.week = week;
	}
	
}
