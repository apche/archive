package sk.rpc.dashboard.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="dashboard_ia")
public class IADomain {

	@Id
	@GeneratedValue(generator="seq_dashboard_ia")
	@SequenceGenerator(name="seq_dashboard_ia",sequenceName="seq_dashboard_ia", allocationSize=1)
	private long id;
	
	@Column(name="teamname")
	private String teamName;
	
	@Column(name="issue_code")
	private String issue;

	@Column(name="status")
	private String status;
	
	@Column(name="ia_responsible")
	private String responsible;
	
	@Column(name="ia_arrived_date")
	private Date arrivedDate;
	
	@Column(name="ia_promised_date")
	private Date promisedDate;
	
	@Column(name="ia_finished_date")
	private Date finishedDate;
	
	@Column(name="ia_effort_estimation")
	private Double effortEstimation;
	
	@Column(name="ia_comment")
	private String comment;

	
	
	
	public IADomain() {
		super();
	}

	public IADomain(long id, String teamName, String issue, String status, String responsible, Date arrivedDate,
			Date promisedDate, Date finishedDate, Double effortEstimation, String comment) {
		super();
		this.id = id;
		this.teamName = teamName;
		this.issue = issue;
		this.status = status;
		this.responsible = responsible;
		this.arrivedDate = arrivedDate;
		this.promisedDate = promisedDate;
		this.finishedDate = finishedDate;
		this.effortEstimation = effortEstimation;
		this.comment = comment;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getIssue() {
		return issue;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getResponsible() {
		return this.responsible;
	}

	public void setResponsible(String responsible) {
		this.responsible = responsible;
	}

	public Date getArrivedDate() {
		return arrivedDate;
	}

	public void setArrivedDate(Date arrivedDate) {
		this.arrivedDate = arrivedDate;
	}

	public Date getPromisedDate() {
		return promisedDate;
	}

	public void setPromisedDate(Date promisedDate) {
		this.promisedDate = promisedDate;
	}

	public Date getFinishedDate() {
		return finishedDate;
	}

	public void setFinishedDate(Date finishedDate) {
		this.finishedDate = finishedDate;
	}

	public Double getEffortEstimation() {
		return effortEstimation;
	}

	public void setEffortEstimation(Double effortEstimation) {
		this.effortEstimation = effortEstimation;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
}
