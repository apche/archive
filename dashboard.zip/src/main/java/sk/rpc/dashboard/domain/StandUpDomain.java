package sk.rpc.dashboard.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.web.context.annotation.SessionScope;

@Entity
@Table(name="stand_up")
@SequenceGenerator(name="seq_stand_up", sequenceName="seq_stand_up")
public class StandUpDomain {

	@Column( name="id", updatable = false)
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="seq_stand_up")
	private Long id;
	
	@Column( name="last_updated_datetime")
	private Date lastUpdatedDateTime;
	
	@Column( name="period_code")
	private String periodCode;
	
	@Column( name="username")
	private String userName;
	
	@Column( name="order_by")
	private Long orderBy;
	
	@Column( name="color")
	private Long color;
	
	@Column( name="issue")
	private String issue;
	
	@Column( name="effort_estimation")
	private Double effortEstimation;
	
	@Column( name="effort_real")
	private Double effortReal;
	
	@Column( name="description")
	private String description;
	
	@Transient
	private String periodType;

	@Transient
	private String msg;

	@Transient
	private Double weekEffortEstimation;	

	@Transient
	private Double weekEffortReal;	

	@Transient
	private String issueInfo;
	
	public StandUpDomain(Long id, Date lastUpdatedDateTime, String periodCode, String userName, Long orderBy, Long color, String issue,
			Double effortEstimation, Double effortReal, String description, String periodType, 
			Double weekEffortEstimation, Double weekEffortReal, String issueInfo) {
		super();
		this.id = id;
		this.lastUpdatedDateTime = lastUpdatedDateTime;
		this.periodCode = periodCode;
		this.userName = userName;
		this.orderBy = orderBy;
		this.color = color;
		this.issue = issue;
		this.effortEstimation = effortEstimation;
		this.effortReal = effortReal;
		this.description = description;
		this.periodType = periodType;
		this.weekEffortEstimation = weekEffortEstimation;
		this.weekEffortReal = weekEffortReal;
		this.issueInfo = issueInfo;
	}
	public StandUpDomain() {
		// TODO Auto-generated constructor stub
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Date getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}
	public void setLastUpdatedDateTime(Date lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}
	/// Getters & setters
	public String getPeriodCode() {
		return periodCode;
	}
	public void setPeriodCode(String periodCode) {
		this.periodCode = periodCode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Long getOrderBy() {
		return orderBy;
	}
	public void setOrderBy(Long orderBy) {
		this.orderBy = orderBy;
	}
	public Long getColor() {
		return color;
	}
	public void setColor(Long color) {
		this.color = color;
	}
	public String getIssue() {
		return issue;
	}
	public void setIssue(String issue) {
		this.issue = issue;
	}
	public Double getEffortEstimation() {
		return effortEstimation;
	}
	public void setEffortEstimation(Double effortEstimation) {
		this.effortEstimation = effortEstimation;
	}
	public Double getEffortReal() {
		return effortReal;
	}
	public void setEffortReal(Double effortReal) {
		this.effortReal = effortReal;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPeriodType() {
		return periodType;
	}
	public void setPeriodType(String periodType) {
		this.periodType = periodType;
	}
	public String getMsg() {
		return msg;
	}
	public Double getWeekEffortReal() {
		return weekEffortReal;
	}
	public void setWeekEffortReal(Double weekEffortReal) {
		this.weekEffortReal = weekEffortReal;
	}
	public Double getWeekEffortEstimation() {
		return weekEffortEstimation;
	}
	public void setWeekEffortEstimation(Double weekEffortEstimation) {
		this.weekEffortEstimation = weekEffortEstimation;
	}
	public String getIssueInfo() {
		return issueInfo;
	}
	public void setIssueInfo(String issueInfo) {
		this.issueInfo = issueInfo;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getElementName( String elemantPrefix){
		return elemantPrefix + '_' + periodCode + '_' +  userName + '_' + orderBy.toString();
	}
	public boolean isJiraIssue(){
		if ( issue == null)
			return false;
		return issue.matches("[a-zA-Z]+-\\d+");
		
	}
}
