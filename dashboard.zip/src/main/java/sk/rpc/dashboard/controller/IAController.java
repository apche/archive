package sk.rpc.dashboard.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import sk.rpc.dashboard.domain.IADomain;
import sk.rpc.dashboard.domain.IAJiraBaseDomain;
import sk.rpc.dashboard.domain.JiraBaseDomain;
import sk.rpc.dashboard.domain.JiraTimeSheetDomain;


@Controller
public class IAController {
	private static final Logger log = LoggerFactory.getLogger(GreetingController.class);

	
	@Autowired
	private JdbcTemplate jdbcTemplate;	
	
	@Transactional(readOnly = true)
    @RequestMapping("/ia_view")
	 public String getIAList(@RequestParam(value="team", required=true) String teamName,
			 @RequestParam(value="editable", required=false) String editable,
	    		Model model){
		
		List<IAJiraBaseDomain> iaList = new ArrayList<IAJiraBaseDomain>();

        jdbcTemplate.query(
                "select ia.id ia_id, ia.teamname, ia.issue_code, ia.status, ia.ia_responsible, " + 
    "ia.ia_arrived_date, ia.ia_promised_date, ia.ia_finished_date, " + 
    "ia.ia_effort_estimation, ia.ia_comment , " + 
    "jb.id, jb.issue, jb.summary, jb.issue_type, jb.issue_status, " + 
    "jb.issue_resolution, jb.assignee, jb.reporter, jb.created, jb.updated " + 
  "from DASHBOARD_IA ia " + 
  "  left join JIRA_BASE jb on ( ia.issue_code = jb.issue)" + 
  "  where ia.status != 'R' " + 
  "  order by ia.status asc, ia.ia_promised_date, ia.id asc", 
                (rs, rowNum) -> new IAJiraBaseDomain(
                		new IADomain(rs.getLong("ia_id"), rs.getString("teamname"), rs.getString("issue_code"),
                				rs.getString("status"), rs.getString("ia_responsible"), rs.getDate("ia_arrived_date"),
                				rs.getDate("ia_promised_date"),rs.getDate("ia_finished_date"),
                				rs.getDouble("ia_effort_estimation"),rs.getString("ia_comment")
                		),
                		new JiraBaseDomain (rs.getLong("id"), rs.getString("issue"),rs.getString("summary"),
                				rs.getString("issue_type"),rs.getString("issue_status"),rs.getString("issue_resolution"),
                				rs.getString("assignee"),rs.getString("reporter"),
                				rs.getDate("created"),rs.getDate("updated")
                		)

				)
        ).forEach(ia -> iaList.add(ia));
		
		
		model.addAttribute("iaList", iaList);
		model.addAttribute("editable", editable);
		return "ia_view";
	}
}
