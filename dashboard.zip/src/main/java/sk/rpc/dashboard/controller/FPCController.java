package sk.rpc.dashboard.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import sk.rpc.dashboard.domain.FpcSequenceDomain;

@Controller
public class FPCController {
	private static final Logger log = LoggerFactory.getLogger(GreetingController.class);
	


	@Autowired
	private JdbcTemplate jdbcTemplate;	
	
	@Transactional(readOnly = true)
    @RequestMapping("/FPC_SEQUENCE")
    public String getFpcSequence(@RequestParam(value="files", required=true) Long files,
    		Model model) {

    	List<FpcSequenceDomain> seqList = new ArrayList<FpcSequenceDomain>();

        jdbcTemplate.query(
                "select SEQ_FPC_ID.nextval id from dual connect by level <= " + files.toString() + "", 
                (rs, rowNum) -> new FpcSequenceDomain(rs.getLong("id"))
        ).forEach(seq -> 	seqList.add(seq));		
        
        /* Find if there is */
        int i = 0;
        Long prevId = new Long(0);
        Long firstId = new Long(0);
        Long lastId = new Long(0);
        boolean b = true;
        for(FpcSequenceDomain seq: seqList){
        	if (i == 0 ){
        		firstId = seq.getId();
        	}
        	if( i > 0){
        		if( prevId != seq.getId()) 
        			b = false;
        	}
        	prevId = seq.getId();
        	i = i + 1;
        }
        lastId = prevId;
        model.addAttribute("seqList", seqList);
        model.addAttribute("firstId", firstId);
        model.addAttribute("lastId", lastId);
        model.addAttribute("correct", b);
        return "fpc_seq_list";
    }	

}







