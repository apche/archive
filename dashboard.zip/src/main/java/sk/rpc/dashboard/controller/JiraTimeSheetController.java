package sk.rpc.dashboard.controller;


import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import sk.rpc.dashboard.domain.JiraTimeSheetDomain;

@Controller
public class JiraTimeSheetController {

	private static final Logger log = LoggerFactory.getLogger(GreetingController.class);
	


	@Autowired
	private JdbcTemplate jdbcTemplate;	
	
	@Transactional(readOnly = true)
    @RequestMapping("/jira_time_sheet")
    public String getRotatorMainPageStatic(@RequestParam(value="team", required=true) String teamName,
    		@RequestParam(value="week", required=false, defaultValue="current") String week,
    		Model model) {

    	List<JiraTimeSheetDomain> timeSheets = new ArrayList<JiraTimeSheetDomain>();

        jdbcTemplate.query(
                "select * from table( pck_jira.f_getTimeSheet( '" + teamName + "', '" + week + "')) ", 
                (rs, rowNum) -> new JiraTimeSheetDomain(rs.getString("week"), rs.getString("teamname"), 
						rs.getString("display_name"), rs.getDouble("jira_hours"), rs.getDouble("hours_to_compare"),
						rs.getDouble("hours_in_week"), rs.getDouble("perc"),rs.getLong("na_pivo_centy"),
						rs.getString("author"),rs.getString("author_issues")
				)
        ).forEach(timeSheet -> timeSheets.add(timeSheet));
          	
        model.addAttribute("timeSheets", timeSheets);
        return "jira_timesheet";
    }	
}
