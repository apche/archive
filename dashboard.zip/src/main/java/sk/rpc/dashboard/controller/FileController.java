package sk.rpc.dashboard.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import sk.rpc.dashboard.domain.DashboardPagesDomain;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import java.io.File;
import java.nio.file.Files;
import java.util.List;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.FileUtils;

import java.net.MalformedURLException;
import  java.net.URL;

@Controller
public class FileController {

	

	@RequestMapping(value = "/get_file", method = RequestMethod.GET) 
	@ResponseBody
	public FileSystemResource getFile(
			@RequestParam(value="fileName", required=true) String fileName,
			/* @PathVariable String fileName, */
			HttpServletRequest request, HttpServletResponse response
			) throws IOException {
		
		String userAgent = request.getHeader("user-agent");
		boolean isInternetExplorer = (userAgent.indexOf("MSIE") > -1);
		
		
		File dwnlFile = new File(System.getProperty("user.dir") + File.separator+"files" + File.separator+fileName);
		
		byte[] fileNameBytes = dwnlFile.getName().getBytes((isInternetExplorer) ? ("windows-1250") : ("utf-8"));
	    String dispositionFileName = "";
	    for (byte b: fileNameBytes) {
	    	dispositionFileName += (char)(b & 0xff);
	    }
	    String contentType = Files.probeContentType(dwnlFile.toPath());
	    if(contentType == null) {
	    	contentType = "application/force-download";
	    }
	    
	    response.setContentType(contentType);
	    
	    String disposition = "attachment; filename=\"" + dispositionFileName + "\"";
		
		response.setHeader("Content-Disposition", disposition);
		response.flushBuffer();
		return new FileSystemResource(dwnlFile);
	} 	
	
    @RequestMapping("/show_pic")
    public String showPic(@RequestParam(value="dashboardname", required=true) String dashboardname,
    		@RequestParam(value="fileName", required=true, defaultValue="0") String fileName,
    		Model model) {
    	
    	
        model.addAttribute("dashboardname", dashboardname);
        model.addAttribute("fileName", fileName);
        model.addAttribute("path", System.getProperty("user.dir"));
        return "show_pic";
    }	
    @RequestMapping("/test_file")
    public String testFile(@RequestParam(value="dashboardname", required=true) String dashboardname,
    		@RequestParam(value="fileName", required=true, defaultValue="0") String fileName,
    		Model model) throws MalformedURLException {

    	
    	try {
			File fromFile=FileUtils.toFile(new URL("file://" + System.getProperty("user.dir") + "/files/a.txt"));
			File toFile=FileUtils.toFile(new URL("file://" + System.getProperty("user.dir") + "/files/b.txt"));
			
			FileUtils.copyFile(fromFile, toFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    	model.addAttribute("dashboardname", dashboardname);
        model.addAttribute("fileName", fileName);
        model.addAttribute("path", System.getProperty("user.dir"));
        return "show_pic";
    	
    }
    
}
