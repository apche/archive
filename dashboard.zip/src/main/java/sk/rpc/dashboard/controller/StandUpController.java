package sk.rpc.dashboard.controller;

import java.util.TreeMap;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;

import sk.rpc.dashboard.domain.StandUpDomain;
import sk.rpc.dashboard.service.StandUpService;

@Controller
public class StandUpController {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private StandUpService standUpService;

	//@Autowired
	//private HttpServletRequest request;
	  
	@RequestMapping("/stand_up_edit")
	public String getStandUpEdit(@RequestParam Map<String,String> allRequestParams,
			@RequestParam(value="team", required=true) String teamName,
			@RequestParam(value="week", required=true) String week,
			@RequestParam(value="username", required=true) String userName,
			Model model){
		
		model.addAttribute("httpRequestText", allRequestParams.toString());
		
		standUpService.loadData(teamName, week, userName);
		standUpService.processRequest( allRequestParams);
		
		model.addAttribute("standUpService", standUpService);
		

		model.addAttribute("editable", true);
		model.addAttribute("week", week);
		model.addAttribute("team", teamName);
		model.addAttribute("username", userName);
		//model.addAttribute("debug", userAgent);

		
		return "stand_up";		
	}
	@RequestMapping("/stand_up")
	public String getStandUp(
			@RequestParam(value="team", required=true) String teamName,
			@RequestParam(value="week", required=true) String week,
			@RequestParam(value="username", required=false, defaultValue = "") String userName, 
			Model model){
		
		standUpService.loadData(teamName, week, userName);
		
		model.addAttribute("standUpService", standUpService);
		model.addAttribute("editable", ! userName.equals("") );
		model.addAttribute("week", week);
		model.addAttribute("team", teamName);
		model.addAttribute("username", userName);
		//model.addAttribute("debug", userAgent);

		
		return "stand_up";
	}

	@RequestMapping("/stand_up_frames")
	public String getStandUpFrames(
			@RequestParam(value="team", required=true) String teamName,
			@RequestParam(value="week", required=true) String week,
			@RequestParam(value="username", required=false, defaultValue = "") String userName, 
			Model model){
		
		
		model.addAttribute("week", week);
		model.addAttribute("team", teamName);
		model.addAttribute("username", userName);
		//model.addAttribute("debug", userAgent);

		
		return "stand_up_frames";
	}	
	
}
