function stateChange(postfix, newState) {
    setTimeout(function(){
        if(newState == -1){loadDoc(postfix);}
    }, 30000);
}

function loadDoc(postfix) {
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("data" + postfix).innerHTML = this.responseText;
		}
	};
	cp = document.getElementById("pageid" + postfix);
	cdash = document.getElementById("dashboard" + postfix);
	cpages = document.getElementById("menu" + postfix).children[0].children;
	if (cp)
		v = parseInt(cp.value);
	else
		v = 0;  
	if(cpages.length <= v)
		v = 0;
	for (i = 0; i < cpages.length; i++) { 
	    if(v ==i){
	    	cpage = cpages[v].children[0];
	    	cpage.className = "current";
	    }else cpages[i].children[0].className = "";
	    	
	}	
	//document.getElementById("data" + postfix).innerHTML = "Loading dashboard....";
	document.getElementById("url" + postfix).value = cpage.href; 
	xhttp.open("GET", cpage.href, true);
	xhttp.send();
	stateChange(postfix, -1);
	cp.value = v + 1;
		

}
stateChange('', -1);
